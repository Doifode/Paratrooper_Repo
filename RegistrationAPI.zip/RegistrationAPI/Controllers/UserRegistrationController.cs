﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using RegistrationAPI.Interface;
using RegistrationAPI.Models;
using StackExchange.Redis;

namespace RegistrationAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserRegistrationController : ControllerBase
    {
        private readonly IUserRegistration _userRegistration;

        public UserRegistrationController(IUserRegistration userRegistration)
        {
            _userRegistration = userRegistration;
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var user = _userRegistration.GetById(id);
            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        [HttpPost]
        [Route("Create")]
        public IActionResult Create(UserRegistration user)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _userRegistration.Add(user);

            return Ok("User Registered Successfully.");
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, UserRegistration user)
        {
            if (id != user.UserId)
            {
                return BadRequest();
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _userRegistration.Update(user);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            _userRegistration.Delete(id);

            return NoContent();
        }

    }
}
