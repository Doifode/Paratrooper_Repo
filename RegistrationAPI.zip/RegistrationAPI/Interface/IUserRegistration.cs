﻿using RegistrationAPI.Models;

namespace RegistrationAPI.Interface
{
    public interface IUserRegistration
    {
        UserRegistration GetById(int userId);
        void Add(UserRegistration user);
        void Update(UserRegistration user);
        void Delete(int userId);
    }
}
