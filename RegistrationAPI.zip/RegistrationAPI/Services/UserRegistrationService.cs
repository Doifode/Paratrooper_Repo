﻿using Microsoft.EntityFrameworkCore;
using RegistrationAPI.Data;
using RegistrationAPI.Interface;
using RegistrationAPI.Models;

namespace RegistrationAPI.Services
{
    public class UserRegistrationService:IUserRegistration
    {
        private readonly ApplicationDbContext context;

        public UserRegistrationService(ApplicationDbContext _context)
        {
            context = _context;
        }

        public UserRegistration GetById(int userId)
        {
            return context.Set<UserRegistration>().Find(userId);
        }

        public void Add(UserRegistration user)
        {
            // Encrypt the password and confirm password
            user.Password = EncryptPassword(user.Password);
            user.ConfirmPassword = EncryptPassword(user.ConfirmPassword);

            context.Set<UserRegistration>().Add(user);
            context.SaveChanges();
        }

        private string EncryptPassword(string password)
        {
            return BCrypt.Net.BCrypt.HashPassword(password);
        }

        public void Update(UserRegistration user)
        {
            context.Set<UserRegistration>().Update(user);
            context.SaveChanges();
        }

        public void Delete(int userId)
        {
            var user = GetById(userId);
            if (user != null)
            {
                context.Set<UserRegistration>().Remove(user);
                context.SaveChanges();
            }
        }
    }
}
