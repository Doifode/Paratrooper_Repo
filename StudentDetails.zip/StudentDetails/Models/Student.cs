﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentDetails.Models
{
    public class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Marks { get; set; }
        public string State { get; set; }
        public string District { get; set; }
        public string Villege { get; set; }
    }
}